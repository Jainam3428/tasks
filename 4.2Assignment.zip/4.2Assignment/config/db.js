const Sequelize = require('sequelize');

const sequelize = new Sequelize("jainams", "jainams", "x4BUrB29krWCE4Qfaq322XpTUbWqhh78",{
    dialect: "mysql",
    host:"15.206.7.200",
    port:"3310",
});

module.exports = sequelize;