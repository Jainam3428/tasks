const Sequelize = require('sequelize');
const sequelize = require("../config/db");

const Course = sequelize.define("course", {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    course_name:{
        type: Sequelize.STRING,
        allowNull: false,
    },
    course_duration:{
        type: Sequelize.STRING,
        allowNull:false,
    },
    course_fees:{
        type: Sequelize.INTEGER,
        allowNull:false,
    },
});

module.exports = Course;