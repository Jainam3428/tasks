var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({extended: false});
module.exports = function(app){
    // app.get('/todo', function(req, res){
    //     //get data from mongodb and pass it to view
    //     Todo.find({}, function(err, data){
    //         if (err) throw err;
    //         res.render('todo', {todos: data}); 
    //     });
    // });
    app.get('/', (req,res) => {
          res.render('index.ejs');
    });
    app.get('/addcourse', (req,res) => {
        res.render('addcourse.ejs');
    });
    app.post('/addcourse', urlencodedParser, function(req, res){
        res.redirect('/');
        });
    
    app.get('/updatecourse', (req,res) => {
        res.render('updatecourse.ejs');
    });
};