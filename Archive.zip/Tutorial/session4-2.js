var http = require('http');
var fs = require('fs');

var express = require('express');
var bodyParser = require('body-parser');

var app = express();

var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.set('View engine', 'ejs');
app.use('/assets', express.static('assets'));

app.get('/', function(req, res){
    res.render('index.ejs');
});
app.get('/contact', function(req, res){
    res.render('contact.ejs', {qs: req.query});
});
app.post('/contact', urlencodedParser, function(req, res){
    
    res.render('contact-success.ejs', {data: req.body});
});
app.get('/profile/:id', function(req,res){
    var data = {age: 20, job: 'node', hobbies: ['Cricket','WWE','Gaming']};
    res.render('profile.ejs', {person: req.params.id, data: data});
});


app.listen(3000);