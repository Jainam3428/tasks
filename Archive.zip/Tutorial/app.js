// var time =0;

// var timer = setInterval(function(){
//     time += 2;
//     console.log(time + 'seconds have passed');
//     if (time = 5){
//         clearInterval(timer);
//     }
// }, 2000);

// console.log(__dirname);
// console.log(__filename);

     // function expression
// function callFunction(fun){
//     fun();
// }

// var sayBye =function(){
//     console.log('bye');
// };
// callFunction(sayBye);

   // modules
// var stuff = require('./stuff');

// console.log(stuff.counter(['Hi','Hello','World']));
// console.log(stuff.adder(5,6));
// console.log(stuff.adder(stuff.pi,5));

// events
// var events = require('events');

// element.on('click', function(){})

// event emmitter custom events
// var myEmitter = new events.EventEmitter();

// myEmitter.on('someEvent', function(msg){
//     console.log(msg);
// })

// myEmitter.emit('someEvent', 'the event was emitted');

// var util = require('util');

// var person = function(name){
//     this.name = name;
// };
// util.inherits(person, events.EventEmitter);

// var james = new person('james');
// var mary = new person('mary');
// var ryu = new person('ryu');

// var people = [james,mary,ryu];

// people.forEach(function(person){
//     person.on('speak', function(msg){
//         console.log(person.name + ' said: ' + msg);
//     })
// });

// james.emit('speak', 'hey hello');
// ryu.emit('speak', 'I want a curry');
// mary.emit('speak', 'I will make that');

  // file modules
// var fs = require('fs');
    // read file
// var readme = fs.readFileSync('readme.txt', 'utf8');
// console.log(readme);

    //  write file
// var readme = fs.readFileSync('readme.txt', 'utf8');
// fs.writeFileSync('writeme.txt', readme);

   // asyncronous read file
// fs.readFile('readme.txt', 'utf8', function(err, data){
//     console.log(data);
// });

   // async write file   
// fs.readFile('readme.txt', 'utf8', function(err, data){
//     fs.writeFileSync('writeme1.txt', data);
// });
   // deleting file
//fs.unlinkSync('writeme1.txt');
   // creating directory
// fs.mkdir('stuff', function(){
// fs.readFile('readme.txt', 'utf8', function(err, data){
//    if (err) throw err;
//      fs.writeFile('./stuff/writeme.txt', data, (err) => {
//       if(err) throw err;
//      });
//    });
// }); 
   // remove directory
// fs.unlink('./stuff/writeme.txt', function(err, data){
//     if (err) throw err;
//     fs.rmdir('stuff', data, (err) => {
//         if(err) throw err;
//     }); 
// });   
   //  create a server
var http = require('http');

// var server = http.createServer(function(req, res){
//     res.writeHead(200, {'Content-Type': 'text/plain'});
//     res.end('hey hello');
// });

// server.listen(3000, '127.0.0.1');
// console.log('you are listening to port 3000');

   // create readable stream
var fs = require('fs');

// var myreadstream = fs.createReadStream(__dirname + '/readme.txt', 'utf8');

// myreadstream.on('data', function(chunk){
//     console.log('new chunk received:');
//     console.log(chunk);
// });

    // create writeable stream
// var myreadstream = fs.createReadStream(__dirname + '/readme.txt', 'utf8');
// var mywritestream = fs.createWriteStream(__dirname + '/writeme.txt');


// myreadstream.on('data', function(chunk){
//     console.log('new chunk received:');
//     mywritestream.write(chunk);
//  });

   // pipe
// var myreadstream = fs.createReadStream(__dirname + '/readme.txt', 'utf8');
// var mywritestream = fs.createWriteStream(__dirname + '/writeme.txt');

// myreadstream.pipe(mywritestream);
   // using server
// var server = http.createServer(function(req, res){
//     res.writeHead(200, {'Content-Type': 'text/plain'});
//     var myreadstream = fs.createReadStream(__dirname + '/readme.txt', 'utf8');
//     myreadstream.pipe(res);
// });

// server.listen(3000, '127.0.0.1');
// console.log('you are listening to port 3000');

   //serving html pages to client
// var server = http.createServer(function(req, res){
//     res.writeHead(200, {'Content-Type': 'text/html'});
//     var myreadstream = fs.createReadStream(__dirname + '/index.html', 'utf8');
//     myreadstream.pipe(res);
// });

// server.listen(3000, '127.0.0.1');
// console.log('you are listening to port 3000');

   //serving JSON file
//    var server = http.createServer(function(req, res){
//       res.writeHead(200, {'Content-Type': 'application/json'});
//       var myobj ={
//          name:'Jainam',
//          age:'20'
//       };
//       res.end(JSON.stringify(myobj));
//   });
  
//   server.listen(3000, '127.0.0.1');
//   console.log('you are listening to port 3000');

   //basic routing
var server = http.createServer(function(req, res){
   if(req.url === '/home' || req.url === '/'){
      res.writeHead(200, {'Content-Type': 'text/html'});
      fs.createReadStream(__dirname + '/index.html').pipe(res);
   } else if(req.url === '/contact'){
      res.writeHead(200, {'Content-Type': 'text/html'});
      fs.createReadStream(__dirname + '/contact.html').pipe(res);
   } else if(req.url === '/api/jainam'){
      var jainam = [{name: 'jainam', age: 20}, {name: 'darshan', age:21}];
      res.writeHead(200, {'Content-Type': 'application/json'}); 
      res.end(JSON.stringify(jainam)); 
   } else{
      res.writeHead(404, {'Content-Type': 'text/html'});
      fs.createReadStream(__dirname + '/404.html').pipe(res);
   }
});
  
server.listen(3000, '127.0.0.1');
console.log('you are listening to port 3000');

